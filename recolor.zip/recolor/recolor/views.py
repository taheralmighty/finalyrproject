from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import auth
import re

# home page function here
def home(request):
    return render(request, 'home.html')

#re.search ('^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$')
# this is the function to render the signup template
def signup(request):
    if request.method == 'POST':
        if request.POST['email']:
            if request.POST['password1'] == request.POST['password2']:
                try:
                    user = User.objects.get(username=request.POST['email'])
                except User.DoesNotExist:
                    user = User.objects.create_user(
                        request.POST['email'],
                        password=request.POST['password1'],
                    )
                auth.login(request, user)
                return redirect('upload')
            else:
                return render(request, 'signup.html', {'err': 'Mismatched password'})
        else:
            return render(request, 'signup.html', {'err': 'Invalid Email'})
    return render(request, 'signup.html')


# function for login
def login(request):
    if request.method == 'POST':
        user = auth.authenticate(
            username=request.POST['email'],
            password=request.POST['password']
        )
        print('#' * 150)
        print(user)
        print('#' * 150)
        if user is not None:
            print('#' * 150)
            print(user.username, '|', user.is_superuser, '|', user.groups)
            print('#' * 150)

            # for admin logic
            # if user.is_superuser:
            #     auth.login(request, user)
            #     return redirect('admin')

            auth.login(request, user)
            return redirect('upload')
    else:
        return render(request, 'login.html')


# logout function
@login_required(login_url='/login/')
def logout(request):
    if request.method == 'POST':
        auth.logout(request)
        return redirect('login')


# this function will be the actual backbone and the
# logic of the code
@login_required(login_url='/login/')
def upload(request):
    if request.method == 'POST':
        image = request.FILES['file-upload-field']
        print(type(image))
        #input validation
        if image.name.split('.')[-1] in ['jpg', 'png', 'jpeg']:
            # actual conversion logic will happen here
            context = {
                'msg': f'File {image} successful',
                'image': image
            }
            return render(request, 'upload.html', context)
        else:
            return render(request, 'upload.html', {'msg': f'File format {image.name} is invalid'})
    return render(request, 'upload.html')

@login_required(login_url='/login/')
def admin(request):
    return render(request, 'admin.html')
